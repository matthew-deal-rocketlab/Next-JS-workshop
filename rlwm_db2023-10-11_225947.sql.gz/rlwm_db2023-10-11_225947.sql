--
-- PostgreSQL database dump
--

-- Dumped from database version 15.3
-- Dumped by pg_dump version 15.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: directus_activity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directus_activity (
    id integer NOT NULL,
    action character varying(45) NOT NULL,
    "user" uuid,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ip character varying(50),
    user_agent character varying(255),
    collection character varying(64) NOT NULL,
    item character varying(255) NOT NULL,
    comment text,
    origin character varying(255)
);


--
-- Name: directus_activity_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.directus_activity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: directus_activity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.directus_activity_id_seq OWNED BY public.directus_activity.id;


--
-- Name: directus_collections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directus_collections (
    collection character varying(64) NOT NULL,
    icon character varying(30),
    note text,
    display_template character varying(255),
    hidden boolean DEFAULT false NOT NULL,
    singleton boolean DEFAULT false NOT NULL,
    translations json,
    archive_field character varying(64),
    archive_app_filter boolean DEFAULT true NOT NULL,
    archive_value character varying(255),
    unarchive_value character varying(255),
    sort_field character varying(64),
    accountability character varying(255) DEFAULT 'all'::character varying,
    color character varying(255),
    item_duplication_fields json,
    sort integer,
    "group" character varying(64),
    collapse character varying(255) DEFAULT 'open'::character varying NOT NULL,
    preview_url character varying(255)
);


--
-- Name: directus_dashboards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directus_dashboards (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    icon character varying(30) DEFAULT 'dashboard'::character varying NOT NULL,
    note text,
    date_created timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    user_created uuid,
    color character varying(255)
);


--
-- Name: directus_fields; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directus_fields (
    id integer NOT NULL,
    collection character varying(64) NOT NULL,
    field character varying(64) NOT NULL,
    special character varying(64),
    interface character varying(64),
    options json,
    display character varying(64),
    display_options json,
    readonly boolean DEFAULT false NOT NULL,
    hidden boolean DEFAULT false NOT NULL,
    sort integer,
    width character varying(30) DEFAULT 'full'::character varying,
    translations json,
    note text,
    conditions json,
    required boolean DEFAULT false,
    "group" character varying(64),
    validation json,
    validation_message text
);


--
-- Name: directus_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.directus_fields_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: directus_fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.directus_fields_id_seq OWNED BY public.directus_fields.id;


--
-- Name: directus_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directus_files (
    id uuid NOT NULL,
    storage character varying(255) NOT NULL,
    filename_disk character varying(255),
    filename_download character varying(255) NOT NULL,
    title character varying(255),
    type character varying(255),
    folder uuid,
    uploaded_by uuid,
    uploaded_on timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    modified_by uuid,
    modified_on timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    charset character varying(50),
    filesize bigint,
    width integer,
    height integer,
    duration integer,
    embed character varying(200),
    description text,
    location text,
    tags text,
    metadata json
);


--
-- Name: directus_flows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directus_flows (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    icon character varying(30),
    color character varying(255),
    description text,
    status character varying(255) DEFAULT 'active'::character varying NOT NULL,
    trigger character varying(255),
    accountability character varying(255) DEFAULT 'all'::character varying,
    options json,
    operation uuid,
    date_created timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    user_created uuid
);


--
-- Name: directus_folders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directus_folders (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    parent uuid
);


--
-- Name: directus_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directus_migrations (
    version character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: directus_notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directus_notifications (
    id integer NOT NULL,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(255) DEFAULT 'inbox'::character varying,
    recipient uuid NOT NULL,
    sender uuid,
    subject character varying(255) NOT NULL,
    message text,
    collection character varying(64),
    item character varying(255)
);


--
-- Name: directus_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.directus_notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: directus_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.directus_notifications_id_seq OWNED BY public.directus_notifications.id;


--
-- Name: directus_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directus_operations (
    id uuid NOT NULL,
    name character varying(255),
    key character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    position_x integer NOT NULL,
    position_y integer NOT NULL,
    options json,
    resolve uuid,
    reject uuid,
    flow uuid NOT NULL,
    date_created timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    user_created uuid
);


--
-- Name: directus_panels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directus_panels (
    id uuid NOT NULL,
    dashboard uuid NOT NULL,
    name character varying(255),
    icon character varying(30) DEFAULT NULL::character varying,
    color character varying(10),
    show_header boolean DEFAULT false NOT NULL,
    note text,
    type character varying(255) NOT NULL,
    position_x integer NOT NULL,
    position_y integer NOT NULL,
    width integer NOT NULL,
    height integer NOT NULL,
    options json,
    date_created timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    user_created uuid
);


--
-- Name: directus_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directus_permissions (
    id integer NOT NULL,
    role uuid,
    collection character varying(64) NOT NULL,
    action character varying(10) NOT NULL,
    permissions json,
    validation json,
    presets json,
    fields text
);


--
-- Name: directus_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.directus_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: directus_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.directus_permissions_id_seq OWNED BY public.directus_permissions.id;


--
-- Name: directus_presets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directus_presets (
    id integer NOT NULL,
    bookmark character varying(255),
    "user" uuid,
    role uuid,
    collection character varying(64),
    search character varying(100),
    layout character varying(100) DEFAULT 'tabular'::character varying,
    layout_query json,
    layout_options json,
    refresh_interval integer,
    filter json,
    icon character varying(30) DEFAULT 'bookmark'::character varying,
    color character varying(255)
);


--
-- Name: directus_presets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.directus_presets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: directus_presets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.directus_presets_id_seq OWNED BY public.directus_presets.id;


--
-- Name: directus_relations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directus_relations (
    id integer NOT NULL,
    many_collection character varying(64) NOT NULL,
    many_field character varying(64) NOT NULL,
    one_collection character varying(64),
    one_field character varying(64),
    one_collection_field character varying(64),
    one_allowed_collections text,
    junction_field character varying(64),
    sort_field character varying(64),
    one_deselect_action character varying(255) DEFAULT 'nullify'::character varying NOT NULL
);


--
-- Name: directus_relations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.directus_relations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: directus_relations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.directus_relations_id_seq OWNED BY public.directus_relations.id;


--
-- Name: directus_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directus_revisions (
    id integer NOT NULL,
    activity integer NOT NULL,
    collection character varying(64) NOT NULL,
    item character varying(255) NOT NULL,
    data json,
    delta json,
    parent integer
);


--
-- Name: directus_revisions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.directus_revisions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: directus_revisions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.directus_revisions_id_seq OWNED BY public.directus_revisions.id;


--
-- Name: directus_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directus_roles (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    icon character varying(30) DEFAULT 'supervised_user_circle'::character varying NOT NULL,
    description text,
    ip_access text,
    enforce_tfa boolean DEFAULT false NOT NULL,
    admin_access boolean DEFAULT false NOT NULL,
    app_access boolean DEFAULT true NOT NULL
);


--
-- Name: directus_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directus_sessions (
    token character varying(64) NOT NULL,
    "user" uuid,
    expires timestamp with time zone NOT NULL,
    ip character varying(255),
    user_agent character varying(255),
    share uuid,
    origin character varying(255)
);


--
-- Name: directus_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directus_settings (
    id integer NOT NULL,
    project_name character varying(100) DEFAULT 'Directus'::character varying NOT NULL,
    project_url character varying(255),
    project_color character varying(50) DEFAULT NULL::character varying,
    project_logo uuid,
    public_foreground uuid,
    public_background uuid,
    public_note text,
    auth_login_attempts integer DEFAULT 25,
    auth_password_policy character varying(100),
    storage_asset_transform character varying(7) DEFAULT 'all'::character varying,
    storage_asset_presets json,
    custom_css text,
    storage_default_folder uuid,
    basemaps json,
    mapbox_key character varying(255),
    module_bar json,
    project_descriptor character varying(100),
    default_language character varying(255) DEFAULT 'en-US'::character varying NOT NULL,
    custom_aspect_ratios json
);


--
-- Name: directus_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.directus_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: directus_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.directus_settings_id_seq OWNED BY public.directus_settings.id;


--
-- Name: directus_shares; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directus_shares (
    id uuid NOT NULL,
    name character varying(255),
    collection character varying(64),
    item character varying(255),
    role uuid,
    password character varying(255),
    user_created uuid,
    date_created timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    date_start timestamp with time zone,
    date_end timestamp with time zone,
    times_used integer DEFAULT 0,
    max_uses integer
);


--
-- Name: directus_translations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directus_translations (
    id uuid NOT NULL,
    language character varying(255) NOT NULL,
    key character varying(255) NOT NULL,
    value text NOT NULL
);


--
-- Name: directus_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directus_users (
    id uuid NOT NULL,
    first_name character varying(50),
    last_name character varying(50),
    email character varying(128),
    password character varying(255),
    location character varying(255),
    title character varying(50),
    description text,
    tags json,
    avatar uuid,
    language character varying(255) DEFAULT NULL::character varying,
    theme character varying(20) DEFAULT 'auto'::character varying,
    tfa_secret character varying(255),
    status character varying(16) DEFAULT 'active'::character varying NOT NULL,
    role uuid,
    token character varying(255),
    last_access timestamp with time zone,
    last_page character varying(255),
    provider character varying(128) DEFAULT 'default'::character varying NOT NULL,
    external_identifier character varying(255),
    auth_data json,
    email_notifications boolean DEFAULT true
);


--
-- Name: directus_webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directus_webhooks (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    method character varying(10) DEFAULT 'POST'::character varying NOT NULL,
    url character varying(255) NOT NULL,
    status character varying(10) DEFAULT 'active'::character varying NOT NULL,
    data boolean DEFAULT true NOT NULL,
    actions character varying(100) NOT NULL,
    collections character varying(255) NOT NULL,
    headers json
);


--
-- Name: directus_webhooks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.directus_webhooks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: directus_webhooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.directus_webhooks_id_seq OWNED BY public.directus_webhooks.id;


--
-- Name: tbl_collection; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tbl_collection (
    id integer NOT NULL,
    name character varying(255),
    user_id integer NOT NULL
);


--
-- Name: tbl_collection_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tbl_collection_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tbl_collection_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tbl_collection_id_seq OWNED BY public.tbl_collection.id;


--
-- Name: tbl_site; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tbl_site (
    id integer NOT NULL,
    user_id integer,
    timeout integer DEFAULT 30,
    url text,
    width integer,
    height integer,
    collection_id integer,
    useragent character varying(255),
    cookies json,
    frequency character varying(255),
    freqtime timestamp without time zone,
    freqtimezone character varying(255)
);


--
-- Name: tbl_site_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tbl_site_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tbl_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tbl_site_id_seq OWNED BY public.tbl_site.id;


--
-- Name: tbl_user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tbl_user (
    date_created timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    date_updated timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    email character varying(255) DEFAULT NULL::character varying NOT NULL,
    firstname character varying(255) DEFAULT NULL::character varying,
    id integer NOT NULL,
    lastname character varying(255) DEFAULT NULL::character varying,
    pass character varying(255) DEFAULT NULL::character varying,
    session character varying(255) DEFAULT NULL::character varying,
    status character varying(1) DEFAULT 'P'::character varying,
    uid uuid DEFAULT gen_random_uuid() NOT NULL,
    verify_code uuid
);


--
-- Name: tbl_user_detail; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tbl_user_detail (
    address text,
    city character varying(255) DEFAULT NULL::character varying,
    company_name character varying(255) DEFAULT NULL::character varying,
    country character varying(255) DEFAULT NULL::character varying,
    id integer NOT NULL,
    language character varying(255) DEFAULT NULL::character varying,
    postcode character varying(255) DEFAULT NULL::character varying,
    state character varying(255) DEFAULT NULL::character varying,
    stripe_id character varying(255) DEFAULT NULL::character varying,
    user_id integer
);


--
-- Name: tbl_user_detail_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tbl_user_detail_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tbl_user_detail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tbl_user_detail_id_seq OWNED BY public.tbl_user_detail.id;


--
-- Name: tbl_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tbl_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tbl_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tbl_user_id_seq OWNED BY public.tbl_user.id;


--
-- Name: directus_activity id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_activity ALTER COLUMN id SET DEFAULT nextval('public.directus_activity_id_seq'::regclass);


--
-- Name: directus_fields id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_fields ALTER COLUMN id SET DEFAULT nextval('public.directus_fields_id_seq'::regclass);


--
-- Name: directus_notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_notifications ALTER COLUMN id SET DEFAULT nextval('public.directus_notifications_id_seq'::regclass);


--
-- Name: directus_permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_permissions ALTER COLUMN id SET DEFAULT nextval('public.directus_permissions_id_seq'::regclass);


--
-- Name: directus_presets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_presets ALTER COLUMN id SET DEFAULT nextval('public.directus_presets_id_seq'::regclass);


--
-- Name: directus_relations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_relations ALTER COLUMN id SET DEFAULT nextval('public.directus_relations_id_seq'::regclass);


--
-- Name: directus_revisions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_revisions ALTER COLUMN id SET DEFAULT nextval('public.directus_revisions_id_seq'::regclass);


--
-- Name: directus_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_settings ALTER COLUMN id SET DEFAULT nextval('public.directus_settings_id_seq'::regclass);


--
-- Name: directus_webhooks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_webhooks ALTER COLUMN id SET DEFAULT nextval('public.directus_webhooks_id_seq'::regclass);


--
-- Name: tbl_collection id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tbl_collection ALTER COLUMN id SET DEFAULT nextval('public.tbl_collection_id_seq'::regclass);


--
-- Name: tbl_site id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tbl_site ALTER COLUMN id SET DEFAULT nextval('public.tbl_site_id_seq'::regclass);


--
-- Name: tbl_user id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tbl_user ALTER COLUMN id SET DEFAULT nextval('public.tbl_user_id_seq'::regclass);


--
-- Name: tbl_user_detail id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tbl_user_detail ALTER COLUMN id SET DEFAULT nextval('public.tbl_user_detail_id_seq'::regclass);


--
-- Data for Name: directus_activity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directus_activity (id, action, "user", "timestamp", ip, user_agent, collection, item, comment, origin) FROM stdin;
1	login	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 01:40:04.934+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_users	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	\N	http://localhost:5002
2	login	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 01:42:38.262+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_users	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	\N	http://localhost:5002
3	login	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:09:51.847+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_users	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	\N	http://localhost:5002
4	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:10:12.507+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_collections	tbl_site	\N	http://localhost:5002
5	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:10:15.414+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_collections	tbl_site	\N	http://localhost:5002
6	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:10:17.288+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_collections	tbl_user	\N	http://localhost:5002
7	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:10:19.456+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_collections	tbl_user	\N	http://localhost:5002
8	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:10:21.509+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_collections	tbl_user_detail	\N	http://localhost:5002
9	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:10:23.841+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_collections	tbl_user_detail	\N	http://localhost:5002
10	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:11:01.676+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	17	\N	http://localhost:5002
11	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:11:03.613+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	17	\N	http://localhost:5002
12	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:11:05.56+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	15	\N	http://localhost:5002
13	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:11:07.195+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	15	\N	http://localhost:5002
14	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:11:08.997+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	13	\N	http://localhost:5002
15	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:11:11.038+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	13	\N	http://localhost:5002
16	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:11:13.494+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	14	\N	http://localhost:5002
17	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:11:15.413+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	14	\N	http://localhost:5002
18	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:11:21.809+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	13	\N	http://localhost:5002
19	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:11:23.766+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	13	\N	http://localhost:5002
20	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:11:26.451+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	14	\N	http://localhost:5002
21	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:11:28.604+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	14	\N	http://localhost:5002
22	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:11:30.668+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	16	\N	http://localhost:5002
23	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:11:37.031+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	18	\N	http://localhost:5002
24	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:11:38.661+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	21	\N	http://localhost:5002
25	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:11:40.369+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	19	\N	http://localhost:5002
26	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:11:42.517+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	20	\N	http://localhost:5002
27	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:11:44.602+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	22	\N	http://localhost:5002
28	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:11:48.109+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	33	\N	http://localhost:5002
29	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:11:51.569+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	33	\N	http://localhost:5002
30	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:11:53.436+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	22	\N	http://localhost:5002
31	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:11:55.659+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	20	\N	http://localhost:5002
32	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:11:57.772+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	19	\N	http://localhost:5002
34	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:12:01.72+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	18	\N	http://localhost:5002
33	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:11:59.663+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	21	\N	http://localhost:5002
35	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:12:03.784+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	16	\N	http://localhost:5002
36	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:27:10.736+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	17	\N	http://localhost:5002
37	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:27:22.309+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	27	\N	http://localhost:5002
38	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:27:44.275+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	32	\N	http://localhost:5002
39	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:28:45.401+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	33	\N	http://localhost:5002
40	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:29:03.863+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	tbl_user	1	\N	http://localhost:5002
41	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 02:29:43.865+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	33	\N	http://localhost:5002
42	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 04:52:16.535+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	34	\N	http://localhost:5002
43	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 04:52:20.081+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	10	\N	http://localhost:5002
44	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 04:52:20.156+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	34	\N	http://localhost:5002
45	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 04:52:20.197+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	12	\N	http://localhost:5002
46	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 04:52:20.24+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	11	\N	http://localhost:5002
47	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 04:52:59.426+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	11	\N	http://localhost:5002
48	login	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 22:36:39.704+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_users	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	\N	http://localhost:5002
49	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 22:36:54.184+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	35	\N	http://localhost:5002
50	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 22:36:54.207+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_collections	test	\N	http://localhost:5002
51	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 22:38:25.952+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	36	\N	http://localhost:5002
52	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-02 22:49:12.672+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	37	\N	http://localhost:5002
55	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-03 00:24:11.048+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	17	\N	http://localhost:5002
56	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-03 00:24:11.198+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	33	\N	http://localhost:5002
57	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-03 00:24:11.293+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	15	\N	http://localhost:5002
58	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-03 00:24:11.38+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	13	\N	http://localhost:5002
59	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-03 00:24:11.463+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	14	\N	http://localhost:5002
60	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-03 00:24:11.624+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	16	\N	http://localhost:5002
61	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-03 00:24:11.707+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	18	\N	http://localhost:5002
62	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-03 00:24:11.775+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	21	\N	http://localhost:5002
63	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-03 00:24:11.841+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	19	\N	http://localhost:5002
64	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-03 00:24:11.905+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	20	\N	http://localhost:5002
65	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-03 00:24:11.962+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	22	\N	http://localhost:5002
66	login	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-04 11:55:22.739+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_users	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	\N	http://localhost:5002
67	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-04 12:10:35.983+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	38	\N	http://localhost:5002
68	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-04 12:10:51.825+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	38	\N	http://localhost:5002
69	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-04 12:14:17.51+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	15	\N	http://localhost:5002
70	delete	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-04 12:45:31.791+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	tbl_user	1	\N	http://localhost:5002
71	delete	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-04 12:45:31.795+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	tbl_user	2	\N	http://localhost:5002
72	delete	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-04 12:45:31.798+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	tbl_user	3	\N	http://localhost:5002
73	delete	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-04 12:45:31.801+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	tbl_user	4	\N	http://localhost:5002
74	delete	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-04 13:42:16.603+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_collections	test	\N	http://localhost:5002
75	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-04 14:29:10.133+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	17	\N	http://localhost:5002
76	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-04 14:31:58.9+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	39	\N	http://localhost:5002
77	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-04 14:31:58.917+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_collections	testme	\N	http://localhost:5002
78	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-04 14:32:08.151+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	40	\N	http://localhost:5002
79	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-04 14:32:12.613+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	39	\N	http://localhost:5002
81	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-04 14:32:48.574+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	17	\N	http://localhost:5002
82	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-04 14:32:59.385+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	tbl_user	10	\N	http://localhost:5002
83	delete	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-04 14:33:13.682+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_collections	testme	\N	http://localhost:5002
84	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-04 14:33:52.823+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	21	\N	http://localhost:5002
85	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-04 14:34:05.503+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	tbl_user	11	\N	http://localhost:5002
86	delete	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-04 14:34:16.239+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	tbl_user	7	\N	http://localhost:5002
87	delete	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-04 14:34:16.244+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	tbl_user	8	\N	http://localhost:5002
88	delete	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-04 14:34:16.247+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	tbl_user	9	\N	http://localhost:5002
89	delete	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-04 14:34:16.25+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	tbl_user	10	\N	http://localhost:5002
90	delete	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-04 14:34:16.254+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	tbl_user	11	\N	http://localhost:5002
91	delete	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-04 14:34:21.846+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	tbl_user_detail	8	\N	http://localhost:5002
92	login	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 01:57:29.987+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_users	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	\N	http://localhost:5002
93	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 02:09:24.312+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	41	\N	http://localhost:5002
94	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 02:09:24.327+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_collections	tbl_collection	\N	http://localhost:5002
95	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 02:13:56.853+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	42	\N	http://localhost:5002
96	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 03:44:28.495+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	43	\N	http://localhost:5002
97	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 03:44:44.511+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	tbl_collection	1	\N	http://localhost:5002
98	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 03:49:14.607+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	44	\N	http://localhost:5002
99	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 03:49:18.144+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	10	\N	http://localhost:5002
100	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 03:49:18.199+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	44	\N	http://localhost:5002
101	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 03:49:18.255+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	12	\N	http://localhost:5002
102	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 03:49:18.304+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	11	\N	http://localhost:5002
103	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 04:23:57.678+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	45	\N	http://localhost:5002
105	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 04:27:48.444+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	47	\N	http://localhost:5002
106	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 04:27:54.249+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	10	\N	http://localhost:5002
107	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 04:27:54.311+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	44	\N	http://localhost:5002
108	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 04:27:54.376+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	47	\N	http://localhost:5002
109	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 04:27:54.463+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	12	\N	http://localhost:5002
110	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 04:27:54.516+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	11	\N	http://localhost:5002
111	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 04:27:54.559+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	45	\N	http://localhost:5002
112	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 04:27:54.605+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	46	\N	http://localhost:5002
104	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 04:24:14.493+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	46	\N	http://localhost:5002
113	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 04:29:44.77+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	48	\N	http://localhost:5002
114	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 04:30:45.303+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	49	\N	http://localhost:5002
115	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 04:31:32.384+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	tbl_site	164	\N	http://localhost:5002
116	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 04:34:48.196+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	50	\N	http://localhost:5002
117	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 04:39:42.194+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	51	\N	http://localhost:5002
118	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 04:42:50.624+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	52	\N	http://localhost:5002
119	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 11:05:59.751+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	43	\N	http://localhost:5002
120	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 12:13:07.689+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	53	\N	http://localhost:5002
121	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 12:13:12.126+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	27	\N	http://localhost:5002
122	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 12:13:12.178+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	53	\N	http://localhost:5002
123	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 12:13:12.227+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	25	\N	http://localhost:5002
124	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 12:13:12.268+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	23	\N	http://localhost:5002
125	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 12:13:12.316+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	24	\N	http://localhost:5002
126	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 12:13:12.368+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	30	\N	http://localhost:5002
127	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 12:13:12.414+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	29	\N	http://localhost:5002
128	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 12:13:12.477+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	26	\N	http://localhost:5002
129	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 12:13:12.514+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	28	\N	http://localhost:5002
130	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 12:13:12.563+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	31	\N	http://localhost:5002
131	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 12:13:37.659+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	41	\N	http://localhost:5002
132	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 12:13:37.749+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	43	\N	http://localhost:5002
133	update	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 12:13:37.802+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_fields	42	\N	http://localhost:5002
134	login	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 23:16:22.48+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	directus_users	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	\N	http://localhost:5002
135	delete	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 23:17:06.955+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	tbl_user_detail	8	\N	http://localhost:5002
136	delete	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 23:17:10.304+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	tbl_user_detail	9	\N	http://localhost:5002
137	create	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-08-08 23:17:29.001+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36	tbl_user_detail	10	\N	http://localhost:5002
138	login	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-09-21 14:25:57.455+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36	directus_users	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	\N	http://localhost:5002
139	login	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-10-11 10:33:24.462+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36	directus_users	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	\N	http://localhost:5002
\.


--
-- Data for Name: directus_collections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directus_collections (collection, icon, note, display_template, hidden, singleton, translations, archive_field, archive_app_filter, archive_value, unarchive_value, sort_field, accountability, color, item_duplication_fields, sort, "group", collapse, preview_url) FROM stdin;
tbl_site	\N	\N	\N	f	f	\N	\N	t	\N	\N	\N	all	\N	\N	\N	\N	open	\N
tbl_user	\N	\N	\N	f	f	\N	\N	t	\N	\N	\N	all	\N	\N	\N	\N	open	\N
tbl_user_detail	\N	\N	\N	f	f	\N	\N	t	\N	\N	\N	all	\N	\N	\N	\N	open	\N
tbl_collection	\N	\N	\N	f	f	\N	\N	t	\N	\N	\N	all	\N	\N	\N	\N	open	\N
\.


--
-- Data for Name: directus_dashboards; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directus_dashboards (id, name, icon, note, date_created, user_created, color) FROM stdin;
\.


--
-- Data for Name: directus_fields; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directus_fields (id, collection, field, special, interface, options, display, display_options, readonly, hidden, sort, width, translations, note, conditions, required, "group", validation, validation_message) FROM stdin;
33	tbl_user	uid	uuid	\N	\N	\N	\N	t	f	2	full	\N	\N	\N	t	\N	\N	\N
13	tbl_user	date_created	\N	\N	\N	\N	\N	f	f	4	full	\N	\N	\N	f	\N	\N	\N
14	tbl_user	date_updated	\N	\N	\N	\N	\N	f	f	5	full	\N	\N	\N	f	\N	\N	\N
16	tbl_user	firstname	\N	\N	\N	\N	\N	f	f	6	full	\N	\N	\N	f	\N	\N	\N
18	tbl_user	lastname	\N	\N	\N	\N	\N	f	f	7	full	\N	\N	\N	f	\N	\N	\N
19	tbl_user	pass	\N	\N	\N	\N	\N	f	f	9	full	\N	\N	\N	f	\N	\N	\N
20	tbl_user	session	\N	\N	\N	\N	\N	f	f	10	full	\N	\N	\N	f	\N	\N	\N
38	tbl_user	verify_code	\N	input	\N	\N	\N	f	f	11	full	\N	\N	\N	f	\N	\N	\N
15	tbl_user	email	\N	\N	\N	\N	\N	f	f	3	full	\N	\N	\N	f	\N	\N	\N
24	tbl_user_detail	city	\N	input	\N	\N	\N	f	f	5	full	\N	\N	\N	f	\N	\N	\N
30	tbl_user_detail	state	\N	input	{"placeholder":"State, region or territory"}	\N	\N	f	f	6	full	\N	\N	\N	f	\N	\N	\N
17	tbl_user	id	\N	\N	\N	\N	\N	t	f	1	full	\N	\N	\N	f	\N	\N	\N
21	tbl_user	status	\N	\N	\N	\N	\N	f	f	8	full	\N	\N	\N	f	\N	\N	\N
29	tbl_user_detail	postcode	\N	input	\N	\N	\N	f	f	7	full	\N	\N	\N	f	\N	\N	\N
26	tbl_user_detail	country	\N	input	\N	\N	\N	f	f	8	full	\N	\N	\N	f	\N	\N	\N
28	tbl_user_detail	language	\N	input	\N	\N	\N	f	f	9	full	\N	\N	\N	f	\N	\N	\N
31	tbl_user_detail	stripe_id	\N	input	\N	\N	\N	f	f	10	full	\N	\N	\N	f	\N	\N	\N
10	tbl_site	id	\N	input	\N	\N	\N	t	t	1	full	\N	\N	\N	f	\N	\N	\N
44	tbl_site	user_id	m2o	select-dropdown-m2o	{"template":"{{email}}"}	\N	\N	f	f	2	full	\N	\N	\N	t	\N	\N	\N
47	tbl_site	collection_id	m2o	select-dropdown-m2o	\N	\N	\N	f	f	3	full	\N	\N	\N	t	\N	\N	\N
12	tbl_site	url	\N	input	\N	\N	\N	f	f	4	full	\N	\N	\N	t	\N	\N	\N
11	tbl_site	timeout	\N	input	\N	\N	\N	f	f	5	full	\N	\N	\N	t	\N	\N	\N
45	tbl_site	width	\N	input	{"min":null}	\N	\N	f	f	6	full	\N	\N	\N	t	\N	\N	\N
46	tbl_site	height	\N	input	\N	\N	\N	f	f	7	full	\N	\N	\N	t	\N	\N	\N
48	tbl_site	useragent	\N	input	\N	\N	\N	f	f	8	full	\N	\N	\N	f	\N	\N	\N
49	tbl_site	cookies	cast-json	input-code	{}	\N	\N	f	f	9	full	\N	\N	\N	f	\N	\N	\N
50	tbl_site	frequency	\N	select-dropdown	\N	\N	\N	f	f	10	full	\N	\N	\N	f	\N	\N	\N
51	tbl_site	freqtime	\N	datetime	\N	\N	\N	f	f	11	full	\N	\N	\N	f	\N	\N	\N
52	tbl_site	freqtimezone	\N	input	\N	\N	\N	f	f	12	full	\N	\N	\N	f	\N	\N	\N
27	tbl_user_detail	id	\N	input	\N	\N	\N	f	t	1	full	\N	\N	\N	f	\N	\N	\N
53	tbl_user_detail	user_id	m2o	select-dropdown-m2o	\N	\N	\N	f	f	2	full	\N	\N	\N	t	\N	\N	\N
25	tbl_user_detail	company_name	\N	input	\N	\N	\N	f	f	3	full	\N	\N	\N	f	\N	\N	\N
23	tbl_user_detail	address	\N	input-multiline	\N	\N	\N	f	f	4	full	\N	\N	\N	f	\N	\N	\N
41	tbl_collection	id	\N	input	\N	\N	\N	t	t	1	full	\N	\N	\N	f	\N	\N	\N
43	tbl_collection	user_id	m2o	select-dropdown-m2o	{"template":"{{email}}"}	\N	\N	f	f	2	full	\N	\N	\N	t	\N	\N	\N
42	tbl_collection	name	\N	input	\N	\N	\N	f	f	3	full	\N	\N	\N	t	\N	\N	\N
\.


--
-- Data for Name: directus_files; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directus_files (id, storage, filename_disk, filename_download, title, type, folder, uploaded_by, uploaded_on, modified_by, modified_on, charset, filesize, width, height, duration, embed, description, location, tags, metadata) FROM stdin;
\.


--
-- Data for Name: directus_flows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directus_flows (id, name, icon, color, description, status, trigger, accountability, options, operation, date_created, user_created) FROM stdin;
\.


--
-- Data for Name: directus_folders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directus_folders (id, name, parent) FROM stdin;
\.


--
-- Data for Name: directus_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directus_migrations (version, name, "timestamp") FROM stdin;
20201028A	Remove Collection Foreign Keys	2023-08-02 01:38:47.991272+00
20201029A	Remove System Relations	2023-08-02 01:38:48.013416+00
20201029B	Remove System Collections	2023-08-02 01:38:48.022452+00
20201029C	Remove System Fields	2023-08-02 01:38:48.043111+00
20201105A	Add Cascade System Relations	2023-08-02 01:38:48.116358+00
20201105B	Change Webhook URL Type	2023-08-02 01:38:48.125341+00
20210225A	Add Relations Sort Field	2023-08-02 01:38:48.133417+00
20210304A	Remove Locked Fields	2023-08-02 01:38:48.13766+00
20210312A	Webhooks Collections Text	2023-08-02 01:38:48.145262+00
20210331A	Add Refresh Interval	2023-08-02 01:38:48.149185+00
20210415A	Make Filesize Nullable	2023-08-02 01:38:48.156714+00
20210416A	Add Collections Accountability	2023-08-02 01:38:48.161614+00
20210422A	Remove Files Interface	2023-08-02 01:38:48.165079+00
20210506A	Rename Interfaces	2023-08-02 01:38:48.193623+00
20210510A	Restructure Relations	2023-08-02 01:38:48.221239+00
20210518A	Add Foreign Key Constraints	2023-08-02 01:38:48.234782+00
20210519A	Add System Fk Triggers	2023-08-02 01:38:48.274427+00
20210521A	Add Collections Icon Color	2023-08-02 01:38:48.278487+00
20210525A	Add Insights	2023-08-02 01:38:48.310578+00
20210608A	Add Deep Clone Config	2023-08-02 01:38:48.315073+00
20210626A	Change Filesize Bigint	2023-08-02 01:38:48.336189+00
20210716A	Add Conditions to Fields	2023-08-02 01:38:48.349437+00
20210721A	Add Default Folder	2023-08-02 01:38:48.357528+00
20210802A	Replace Groups	2023-08-02 01:38:48.363912+00
20210803A	Add Required to Fields	2023-08-02 01:38:48.36806+00
20210805A	Update Groups	2023-08-02 01:38:48.373286+00
20210805B	Change Image Metadata Structure	2023-08-02 01:38:48.37958+00
20210811A	Add Geometry Config	2023-08-02 01:38:48.383326+00
20210831A	Remove Limit Column	2023-08-02 01:38:48.386576+00
20210903A	Add Auth Provider	2023-08-02 01:38:48.406556+00
20210907A	Webhooks Collections Not Null	2023-08-02 01:38:48.415069+00
20210910A	Move Module Setup	2023-08-02 01:38:48.419793+00
20210920A	Webhooks URL Not Null	2023-08-02 01:38:48.426957+00
20210924A	Add Collection Organization	2023-08-02 01:38:48.433612+00
20210927A	Replace Fields Group	2023-08-02 01:38:48.444189+00
20210927B	Replace M2M Interface	2023-08-02 01:38:48.448077+00
20210929A	Rename Login Action	2023-08-02 01:38:48.451326+00
20211007A	Update Presets	2023-08-02 01:38:48.459238+00
20211009A	Add Auth Data	2023-08-02 01:38:48.462827+00
20211016A	Add Webhook Headers	2023-08-02 01:38:48.466338+00
20211103A	Set Unique to User Token	2023-08-02 01:38:48.472437+00
20211103B	Update Special Geometry	2023-08-02 01:38:48.476446+00
20211104A	Remove Collections Listing	2023-08-02 01:38:48.480193+00
20211118A	Add Notifications	2023-08-02 01:38:48.505205+00
20211211A	Add Shares	2023-08-02 01:38:48.530801+00
20211230A	Add Project Descriptor	2023-08-02 01:38:48.535145+00
20220303A	Remove Default Project Color	2023-08-02 01:38:48.54328+00
20220308A	Add Bookmark Icon and Color	2023-08-02 01:38:48.547792+00
20220314A	Add Translation Strings	2023-08-02 01:38:48.551517+00
20220322A	Rename Field Typecast Flags	2023-08-02 01:38:48.558105+00
20220323A	Add Field Validation	2023-08-02 01:38:48.562319+00
20220325A	Fix Typecast Flags	2023-08-02 01:38:48.567934+00
20220325B	Add Default Language	2023-08-02 01:38:48.578189+00
20220402A	Remove Default Value Panel Icon	2023-08-02 01:38:48.585965+00
20220429A	Add Flows	2023-08-02 01:38:48.636674+00
20220429B	Add Color to Insights Icon	2023-08-02 01:38:48.640464+00
20220429C	Drop Non Null From IP of Activity	2023-08-02 01:38:48.644474+00
20220429D	Drop Non Null From Sender of Notifications	2023-08-02 01:38:48.648989+00
20220614A	Rename Hook Trigger to Event	2023-08-02 01:38:48.652712+00
20220801A	Update Notifications Timestamp Column	2023-08-02 01:38:48.660196+00
20220802A	Add Custom Aspect Ratios	2023-08-02 01:38:48.664369+00
20220826A	Add Origin to Accountability	2023-08-02 01:38:48.66944+00
20230401A	Update Material Icons	2023-08-02 01:38:48.678465+00
20230525A	Add Preview Settings	2023-08-02 01:38:48.682399+00
20230526A	Migrate Translation Strings	2023-08-02 01:38:48.696809+00
\.


--
-- Data for Name: directus_notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directus_notifications (id, "timestamp", status, recipient, sender, subject, message, collection, item) FROM stdin;
\.


--
-- Data for Name: directus_operations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directus_operations (id, name, key, type, position_x, position_y, options, resolve, reject, flow, date_created, user_created) FROM stdin;
\.


--
-- Data for Name: directus_panels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directus_panels (id, dashboard, name, icon, color, show_header, note, type, position_x, position_y, width, height, options, date_created, user_created) FROM stdin;
\.


--
-- Data for Name: directus_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directus_permissions (id, role, collection, action, permissions, validation, presets, fields) FROM stdin;
\.


--
-- Data for Name: directus_presets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directus_presets (id, bookmark, "user", role, collection, search, layout, layout_query, layout_options, refresh_interval, filter, icon, color) FROM stdin;
1	\N	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	\N	tbl_user	\N	\N	{"tabular":{"limit":25,"fields":["id","uid","email","date_created","date_updated","status"]}}	{"tabular":{"widths":{"id":92.43853759765625,"email":190.573974609375}}}	\N	\N	bookmark	\N
4	\N	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	\N	directus_users	\N	cards	{"cards":{"sort":["email"],"limit":25}}	{"cards":{"icon":"account_circle","title":"{{ first_name }} {{ last_name }}","subtitle":"{{ email }}","size":4}}	\N	\N	bookmark	\N
2	\N	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	\N	tbl_user_detail	\N	\N	{"tabular":{"limit":25}}	\N	\N	\N	bookmark	\N
3	\N	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	\N	tbl_site	\N	\N	{"tabular":{"limit":25,"fields":["user_id.email","collection_id.name","url","frequency"]}}	{"tabular":{"widths":{"url":328.6082763671875}}}	\N	\N	bookmark	\N
8	\N	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	\N	tbl_collection	\N	\N	{"tabular":{"limit":25}}	\N	\N	\N	bookmark	\N
6	\N	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	\N	directus_files	\N	cards	{"cards":{"sort":["-uploaded_on"],"limit":25}}	{"cards":{"icon":"insert_drive_file","title":"{{ title }}","subtitle":"{{ type }} • {{ filesize }}","size":4,"imageFit":"crop"}}	\N	\N	bookmark	\N
\.


--
-- Data for Name: directus_relations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directus_relations (id, many_collection, many_field, one_collection, one_field, one_collection_field, one_allowed_collections, junction_field, sort_field, one_deselect_action) FROM stdin;
1	tbl_collection	user_id	tbl_user	\N	\N	\N	\N	\N	nullify
2	tbl_site	user_id	tbl_user	\N	\N	\N	\N	\N	nullify
3	tbl_site	collection_id	tbl_collection	\N	\N	\N	\N	\N	nullify
4	tbl_user_detail	user_id	tbl_user	\N	\N	\N	\N	\N	nullify
\.


--
-- Data for Name: directus_revisions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directus_revisions (id, activity, collection, item, data, delta, parent) FROM stdin;
1	4	directus_collections	tbl_site	{"collection":"tbl_site","icon":null,"note":null,"display_template":null,"hidden":true,"singleton":false,"translations":null,"archive_field":null,"archive_app_filter":true,"archive_value":null,"unarchive_value":null,"sort_field":null,"accountability":"all","color":null,"item_duplication_fields":null,"sort":null,"group":null,"collapse":"open","preview_url":null}	{"hidden":true}	\N
2	5	directus_collections	tbl_site	{"collection":"tbl_site","icon":null,"note":null,"display_template":null,"hidden":false,"singleton":false,"translations":null,"archive_field":null,"archive_app_filter":true,"archive_value":null,"unarchive_value":null,"sort_field":null,"accountability":"all","color":null,"item_duplication_fields":null,"sort":null,"group":null,"collapse":"open","preview_url":null}	{"hidden":false}	\N
3	6	directus_collections	tbl_user	{"collection":"tbl_user","icon":null,"note":null,"display_template":null,"hidden":true,"singleton":false,"translations":null,"archive_field":null,"archive_app_filter":true,"archive_value":null,"unarchive_value":null,"sort_field":null,"accountability":"all","color":null,"item_duplication_fields":null,"sort":null,"group":null,"collapse":"open","preview_url":null}	{"hidden":true}	\N
4	7	directus_collections	tbl_user	{"collection":"tbl_user","icon":null,"note":null,"display_template":null,"hidden":false,"singleton":false,"translations":null,"archive_field":null,"archive_app_filter":true,"archive_value":null,"unarchive_value":null,"sort_field":null,"accountability":"all","color":null,"item_duplication_fields":null,"sort":null,"group":null,"collapse":"open","preview_url":null}	{"hidden":false}	\N
5	8	directus_collections	tbl_user_detail	{"collection":"tbl_user_detail","icon":null,"note":null,"display_template":null,"hidden":true,"singleton":false,"translations":null,"archive_field":null,"archive_app_filter":true,"archive_value":null,"unarchive_value":null,"sort_field":null,"accountability":"all","color":null,"item_duplication_fields":null,"sort":null,"group":null,"collapse":"open","preview_url":null}	{"hidden":true}	\N
6	9	directus_collections	tbl_user_detail	{"collection":"tbl_user_detail","icon":null,"note":null,"display_template":null,"hidden":false,"singleton":false,"translations":null,"archive_field":null,"archive_app_filter":true,"archive_value":null,"unarchive_value":null,"sort_field":null,"accountability":"all","color":null,"item_duplication_fields":null,"sort":null,"group":null,"collapse":"open","preview_url":null}	{"hidden":false}	\N
7	10	directus_fields	17	{"id":17,"collection":"tbl_user","field":"id","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":true,"sort":1,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"id","hidden":true}	\N
8	11	directus_fields	17	{"id":17,"collection":"tbl_user","field":"id","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":1,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"id","hidden":false}	\N
9	12	directus_fields	15	{"id":15,"collection":"tbl_user","field":"email","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":true,"sort":3,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"email","hidden":true}	\N
10	13	directus_fields	15	{"id":15,"collection":"tbl_user","field":"email","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":3,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"email","hidden":false}	\N
11	14	directus_fields	13	{"id":13,"collection":"tbl_user","field":"date_created","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":true,"sort":4,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"date_created","hidden":true}	\N
12	15	directus_fields	13	{"id":13,"collection":"tbl_user","field":"date_created","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":4,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"date_created","hidden":false}	\N
13	16	directus_fields	14	{"id":14,"collection":"tbl_user","field":"date_updated","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":true,"sort":5,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"date_updated","hidden":true}	\N
14	17	directus_fields	14	{"id":14,"collection":"tbl_user","field":"date_updated","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":5,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"date_updated","hidden":false}	\N
15	18	directus_fields	13	{"id":13,"collection":"tbl_user","field":"date_created","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":true,"sort":4,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"date_created","hidden":true}	\N
16	19	directus_fields	13	{"id":13,"collection":"tbl_user","field":"date_created","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":4,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"date_created","hidden":false}	\N
17	20	directus_fields	14	{"id":14,"collection":"tbl_user","field":"date_updated","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":true,"sort":5,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"date_updated","hidden":true}	\N
18	21	directus_fields	14	{"id":14,"collection":"tbl_user","field":"date_updated","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":5,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"date_updated","hidden":false}	\N
19	22	directus_fields	16	{"id":16,"collection":"tbl_user","field":"firstname","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":true,"sort":6,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"firstname","hidden":true}	\N
20	23	directus_fields	18	{"id":18,"collection":"tbl_user","field":"lastname","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":true,"sort":7,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"lastname","hidden":true}	\N
22	25	directus_fields	19	{"id":19,"collection":"tbl_user","field":"pass","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":true,"sort":9,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"pass","hidden":true}	\N
24	27	directus_fields	22	{"id":22,"collection":"tbl_user","field":"verify_code","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":false,"hidden":true,"sort":11,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"verify_code","hidden":true}	\N
26	29	directus_fields	33	{"id":33,"collection":"tbl_user","field":"uid","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":null,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"uid","hidden":false}	\N
28	31	directus_fields	20	{"id":20,"collection":"tbl_user","field":"session","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":10,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"session","hidden":false}	\N
30	33	directus_fields	21	{"id":21,"collection":"tbl_user","field":"status","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":8,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"status","hidden":false}	\N
32	35	directus_fields	16	{"id":16,"collection":"tbl_user","field":"firstname","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":6,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"firstname","hidden":false}	\N
21	24	directus_fields	21	{"id":21,"collection":"tbl_user","field":"status","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":true,"sort":8,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"status","hidden":true}	\N
23	26	directus_fields	20	{"id":20,"collection":"tbl_user","field":"session","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":true,"sort":10,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"session","hidden":true}	\N
25	28	directus_fields	33	{"hidden":true,"collection":"tbl_user","field":"uid"}	{"hidden":true,"collection":"tbl_user","field":"uid"}	\N
27	30	directus_fields	22	{"id":22,"collection":"tbl_user","field":"verify_code","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":11,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"verify_code","hidden":false}	\N
29	32	directus_fields	19	{"id":19,"collection":"tbl_user","field":"pass","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":9,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"pass","hidden":false}	\N
31	34	directus_fields	18	{"id":18,"collection":"tbl_user","field":"lastname","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":7,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"lastname","hidden":false}	\N
33	36	directus_fields	17	{"id":17,"collection":"tbl_user","field":"id","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":true,"sort":1,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"id","hidden":true}	\N
34	37	directus_fields	27	{"id":27,"collection":"tbl_user_detail","field":"id","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":false,"hidden":true,"sort":1,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user_detail","field":"id","hidden":true}	\N
35	38	directus_fields	32	{"id":32,"collection":"tbl_user_detail","field":"uid","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":2,"width":"full","translations":null,"note":null,"conditions":null,"required":true,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user_detail","field":"uid","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":2,"width":"full","translations":null,"note":null,"conditions":null,"required":true,"group":null,"validation":null,"validation_message":null}	\N
36	39	directus_fields	33	{"id":33,"collection":"tbl_user","field":"uid","special":["uuid"],"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":null,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"uid","special":["uuid"],"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":null,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	\N
37	40	tbl_user	1	{"email":"js+dev1@rokt.io","firstname":"john"}	{"email":"js+dev1@rokt.io","firstname":"john"}	\N
38	41	directus_fields	33	{"id":33,"collection":"tbl_user","field":"uid","special":["uuid"],"interface":null,"options":null,"display":null,"display_options":null,"readonly":true,"hidden":false,"sort":null,"width":"full","translations":null,"note":null,"conditions":null,"required":true,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"uid","special":["uuid"],"interface":null,"options":null,"display":null,"display_options":null,"readonly":true,"hidden":false,"sort":null,"width":"full","translations":null,"note":null,"conditions":null,"required":true,"group":null,"validation":null,"validation_message":null}	\N
39	42	directus_fields	34	{"sort":4,"interface":"input","special":null,"required":true,"collection":"tbl_site","field":"user_id"}	{"sort":4,"interface":"input","special":null,"required":true,"collection":"tbl_site","field":"user_id"}	\N
40	43	directus_fields	10	{"id":10,"collection":"tbl_site","field":"id","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":true,"hidden":true,"sort":1,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_site","field":"id","sort":1,"group":null}	\N
41	44	directus_fields	34	{"id":34,"collection":"tbl_site","field":"user_id","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":2,"width":"full","translations":null,"note":null,"conditions":null,"required":true,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_site","field":"user_id","sort":2,"group":null}	\N
42	45	directus_fields	12	{"id":12,"collection":"tbl_site","field":"url","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":3,"width":"full","translations":null,"note":null,"conditions":null,"required":true,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_site","field":"url","sort":3,"group":null}	\N
43	46	directus_fields	11	{"id":11,"collection":"tbl_site","field":"timeout","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":4,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_site","field":"timeout","sort":4,"group":null}	\N
44	47	directus_fields	11	{"id":11,"collection":"tbl_site","field":"timeout","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":4,"width":"full","translations":null,"note":null,"conditions":null,"required":true,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_site","field":"timeout","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":4,"width":"full","translations":null,"note":null,"conditions":null,"required":true,"group":null,"validation":null,"validation_message":null}	\N
45	49	directus_fields	35	{"sort":1,"hidden":true,"interface":"input","readonly":true,"field":"id","collection":"test"}	{"sort":1,"hidden":true,"interface":"input","readonly":true,"field":"id","collection":"test"}	\N
46	50	directus_collections	test	{"singleton":false,"collection":"test"}	{"singleton":false,"collection":"test"}	\N
47	51	directus_fields	36	{"sort":2,"interface":"input","special":["uuid"],"required":true,"collection":"test","field":"uid"}	{"sort":2,"interface":"input","special":["uuid"],"required":true,"collection":"test","field":"uid"}	\N
48	52	directus_fields	37	{"sort":3,"interface":"input","special":null,"collection":"test","field":"test"}	{"sort":3,"interface":"input","special":null,"collection":"test","field":"test"}	\N
51	55	directus_fields	17	{"id":17,"collection":"tbl_user","field":"id","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":true,"sort":1,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"id","sort":1,"group":null}	\N
52	56	directus_fields	33	{"id":33,"collection":"tbl_user","field":"uid","special":["uuid"],"interface":null,"options":null,"display":null,"display_options":null,"readonly":true,"hidden":false,"sort":2,"width":"full","translations":null,"note":null,"conditions":null,"required":true,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"uid","sort":2,"group":null}	\N
53	57	directus_fields	15	{"id":15,"collection":"tbl_user","field":"email","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":3,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"email","sort":3,"group":null}	\N
54	58	directus_fields	13	{"id":13,"collection":"tbl_user","field":"date_created","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":4,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"date_created","sort":4,"group":null}	\N
55	59	directus_fields	14	{"id":14,"collection":"tbl_user","field":"date_updated","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":5,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"date_updated","sort":5,"group":null}	\N
56	60	directus_fields	16	{"id":16,"collection":"tbl_user","field":"firstname","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":6,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"firstname","sort":6,"group":null}	\N
57	61	directus_fields	18	{"id":18,"collection":"tbl_user","field":"lastname","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":7,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"lastname","sort":7,"group":null}	\N
58	62	directus_fields	21	{"id":21,"collection":"tbl_user","field":"status","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":8,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"status","sort":8,"group":null}	\N
59	63	directus_fields	19	{"id":19,"collection":"tbl_user","field":"pass","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":9,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"pass","sort":9,"group":null}	\N
60	64	directus_fields	20	{"id":20,"collection":"tbl_user","field":"session","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":10,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"session","sort":10,"group":null}	\N
61	65	directus_fields	22	{"id":22,"collection":"tbl_user","field":"verify_code","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":11,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"verify_code","sort":11,"group":null}	\N
62	67	directus_fields	38	{"sort":11,"interface":"input","special":["uuid"],"collection":"tbl_user","field":"verify_code"}	{"sort":11,"interface":"input","special":["uuid"],"collection":"tbl_user","field":"verify_code"}	\N
63	68	directus_fields	38	{"id":38,"collection":"tbl_user","field":"verify_code","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":11,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"verify_code","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":11,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	\N
64	69	directus_fields	15	{"id":15,"collection":"tbl_user","field":"email","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":3,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"email","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":3,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	\N
73	84	directus_fields	21	{"id":21,"collection":"tbl_user","field":"status","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":8,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"status","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":8,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	\N
98	116	directus_fields	50	{"sort":10,"interface":"select-dropdown","special":null,"collection":"tbl_site","field":"frequency"}	{"sort":10,"interface":"select-dropdown","special":null,"collection":"tbl_site","field":"frequency"}	\N
101	119	directus_fields	43	{"id":43,"collection":"tbl_collection","field":"user_id","special":["m2o"],"interface":"select-dropdown-m2o","options":{"template":"{{email}}"},"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":3,"width":"full","translations":null,"note":null,"conditions":null,"required":true,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_collection","field":"user_id","special":["m2o"],"interface":"select-dropdown-m2o","options":{"template":"{{email}}"},"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":3,"width":"full","translations":null,"note":null,"conditions":null,"required":true,"group":null,"validation":null,"validation_message":null}	\N
116	137	tbl_user_detail	10	{"user_id":12,"company_name":"Rocket Lab"}	{"user_id":12,"company_name":"Rocket Lab"}	\N
74	85	tbl_user	11	{"email":"kjhkjh@k.com"}	{"email":"kjhkjh@k.com"}	\N
99	117	directus_fields	51	{"sort":11,"interface":"datetime","special":null,"collection":"tbl_site","field":"freqtime"}	{"sort":11,"interface":"datetime","special":null,"collection":"tbl_site","field":"freqtime"}	\N
100	118	directus_fields	52	{"sort":12,"interface":"input","special":null,"collection":"tbl_site","field":"freqtimezone"}	{"sort":12,"interface":"input","special":null,"collection":"tbl_site","field":"freqtimezone"}	\N
75	93	directus_fields	41	{"sort":1,"hidden":true,"interface":"input","readonly":true,"field":"id","collection":"tbl_collection"}	{"sort":1,"hidden":true,"interface":"input","readonly":true,"field":"id","collection":"tbl_collection"}	\N
76	94	directus_collections	tbl_collection	{"singleton":false,"collection":"tbl_collection"}	{"singleton":false,"collection":"tbl_collection"}	\N
77	95	directus_fields	42	{"sort":2,"interface":"input","special":null,"required":true,"collection":"tbl_collection","field":"name"}	{"sort":2,"interface":"input","special":null,"required":true,"collection":"tbl_collection","field":"name"}	\N
80	98	directus_fields	44	{"sort":5,"interface":"select-dropdown-m2o","special":["m2o"],"required":true,"options":{"template":"{{email}}"},"collection":"tbl_site","field":"user_id"}	{"sort":5,"interface":"select-dropdown-m2o","special":["m2o"],"required":true,"options":{"template":"{{email}}"},"collection":"tbl_site","field":"user_id"}	\N
86	104	directus_fields	46	{"sort":6,"interface":"input","special":null,"required":true,"collection":"tbl_site","field":"height"}	{"sort":6,"interface":"input","special":null,"required":true,"collection":"tbl_site","field":"height"}	\N
95	113	directus_fields	48	{"sort":8,"interface":"input","special":null,"collection":"tbl_site","field":"useragent"}	{"sort":8,"interface":"input","special":null,"collection":"tbl_site","field":"useragent"}	\N
96	114	directus_fields	49	{"sort":9,"interface":"input-code","special":["cast-json"],"options":{},"collection":"tbl_site","field":"cookies"}	{"sort":9,"interface":"input-code","special":["cast-json"],"options":{},"collection":"tbl_site","field":"cookies"}	\N
102	120	directus_fields	53	{"sort":11,"interface":"select-dropdown-m2o","special":["m2o"],"required":true,"collection":"tbl_user_detail","field":"user_id"}	{"sort":11,"interface":"select-dropdown-m2o","special":["m2o"],"required":true,"collection":"tbl_user_detail","field":"user_id"}	\N
78	96	directus_fields	43	{"sort":3,"interface":"select-dropdown-m2o","special":["m2o"],"required":true,"options":{"template":"{{email}}"},"collection":"tbl_collection","field":"user_id"}	{"sort":3,"interface":"select-dropdown-m2o","special":["m2o"],"required":true,"options":{"template":"{{email}}"},"collection":"tbl_collection","field":"user_id"}	\N
79	97	tbl_collection	1	{"name":"test","user_id":13}	{"name":"test","user_id":13}	\N
81	99	directus_fields	10	{"id":10,"collection":"tbl_site","field":"id","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":true,"hidden":true,"sort":1,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_site","field":"id","sort":1,"group":null}	\N
82	100	directus_fields	44	{"id":44,"collection":"tbl_site","field":"user_id","special":["m2o"],"interface":"select-dropdown-m2o","options":{"template":"{{email}}"},"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":2,"width":"full","translations":null,"note":null,"conditions":null,"required":true,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_site","field":"user_id","sort":2,"group":null}	\N
83	101	directus_fields	12	{"id":12,"collection":"tbl_site","field":"url","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":3,"width":"full","translations":null,"note":null,"conditions":null,"required":true,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_site","field":"url","sort":3,"group":null}	\N
84	102	directus_fields	11	{"id":11,"collection":"tbl_site","field":"timeout","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":4,"width":"full","translations":null,"note":null,"conditions":null,"required":true,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_site","field":"timeout","sort":4,"group":null}	\N
85	103	directus_fields	45	{"sort":5,"interface":"input","special":null,"required":true,"options":{"min":null},"collection":"tbl_site","field":"width"}	{"sort":5,"interface":"input","special":null,"required":true,"options":{"min":null},"collection":"tbl_site","field":"width"}	\N
87	105	directus_fields	47	{"sort":7,"interface":"select-dropdown-m2o","special":["m2o"],"required":true,"collection":"tbl_site","field":"collection_id"}	{"sort":7,"interface":"select-dropdown-m2o","special":["m2o"],"required":true,"collection":"tbl_site","field":"collection_id"}	\N
88	106	directus_fields	10	{"id":10,"collection":"tbl_site","field":"id","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":true,"hidden":true,"sort":1,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_site","field":"id","sort":1,"group":null}	\N
89	107	directus_fields	44	{"id":44,"collection":"tbl_site","field":"user_id","special":["m2o"],"interface":"select-dropdown-m2o","options":{"template":"{{email}}"},"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":2,"width":"full","translations":null,"note":null,"conditions":null,"required":true,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_site","field":"user_id","sort":2,"group":null}	\N
90	108	directus_fields	47	{"id":47,"collection":"tbl_site","field":"collection_id","special":["m2o"],"interface":"select-dropdown-m2o","options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":3,"width":"full","translations":null,"note":null,"conditions":null,"required":true,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_site","field":"collection_id","sort":3,"group":null}	\N
91	109	directus_fields	12	{"id":12,"collection":"tbl_site","field":"url","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":4,"width":"full","translations":null,"note":null,"conditions":null,"required":true,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_site","field":"url","sort":4,"group":null}	\N
92	110	directus_fields	11	{"id":11,"collection":"tbl_site","field":"timeout","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":5,"width":"full","translations":null,"note":null,"conditions":null,"required":true,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_site","field":"timeout","sort":5,"group":null}	\N
65	75	directus_fields	17	{"id":17,"collection":"tbl_user","field":"id","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":true,"hidden":false,"sort":1,"width":"full","translations":null,"note":null,"conditions":null,"required":true,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"id","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":true,"hidden":false,"sort":1,"width":"full","translations":null,"note":null,"conditions":null,"required":true,"group":null,"validation":null,"validation_message":null}	\N
66	76	directus_fields	39	{"sort":1,"hidden":true,"interface":"input","readonly":true,"field":"id","collection":"testme"}	{"sort":1,"hidden":true,"interface":"input","readonly":true,"field":"id","collection":"testme"}	\N
67	77	directus_collections	testme	{"singleton":false,"collection":"testme"}	{"singleton":false,"collection":"testme"}	\N
68	78	directus_fields	40	{"sort":2,"interface":"input","special":null,"collection":"testme","field":"input"}	{"sort":2,"interface":"input","special":null,"collection":"testme","field":"input"}	\N
69	79	directus_fields	39	{"id":39,"collection":"testme","field":"id","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":true,"hidden":false,"sort":1,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"testme","field":"id","hidden":false}	\N
93	111	directus_fields	45	{"id":45,"collection":"tbl_site","field":"width","special":null,"interface":"input","options":{"min":null},"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":6,"width":"full","translations":null,"note":null,"conditions":null,"required":true,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_site","field":"width","sort":6,"group":null}	\N
94	112	directus_fields	46	{"id":46,"collection":"tbl_site","field":"height","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":7,"width":"full","translations":null,"note":null,"conditions":null,"required":true,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_site","field":"height","sort":7,"group":null}	\N
71	81	directus_fields	17	{"id":17,"collection":"tbl_user","field":"id","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":true,"hidden":false,"sort":1,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user","field":"id","special":null,"interface":null,"options":null,"display":null,"display_options":null,"readonly":true,"hidden":false,"sort":1,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	\N
72	82	tbl_user	10	{"email":"sdfdsf@sdfdsfs.com"}	{"email":"sdfdsf@sdfdsfs.com"}	\N
97	115	tbl_site	164	{"id":164,"timeout":30,"url":"http://www.example.com/about","user_id":13,"width":1024,"height":30000,"collection_id":1,"useragent":null,"cookies":null}	{"user_id":13,"width":1024,"height":30000,"collection_id":1}	\N
103	121	directus_fields	27	{"id":27,"collection":"tbl_user_detail","field":"id","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":false,"hidden":true,"sort":1,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user_detail","field":"id","sort":1,"group":null}	\N
104	122	directus_fields	53	{"id":53,"collection":"tbl_user_detail","field":"user_id","special":["m2o"],"interface":"select-dropdown-m2o","options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":2,"width":"full","translations":null,"note":null,"conditions":null,"required":true,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user_detail","field":"user_id","sort":2,"group":null}	\N
105	123	directus_fields	25	{"id":25,"collection":"tbl_user_detail","field":"company_name","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":3,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user_detail","field":"company_name","sort":3,"group":null}	\N
106	124	directus_fields	23	{"id":23,"collection":"tbl_user_detail","field":"address","special":null,"interface":"input-multiline","options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":4,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user_detail","field":"address","sort":4,"group":null}	\N
107	125	directus_fields	24	{"id":24,"collection":"tbl_user_detail","field":"city","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":5,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user_detail","field":"city","sort":5,"group":null}	\N
108	126	directus_fields	30	{"id":30,"collection":"tbl_user_detail","field":"state","special":null,"interface":"input","options":{"placeholder":"State, region or territory"},"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":6,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user_detail","field":"state","sort":6,"group":null}	\N
109	127	directus_fields	29	{"id":29,"collection":"tbl_user_detail","field":"postcode","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":7,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user_detail","field":"postcode","sort":7,"group":null}	\N
110	128	directus_fields	26	{"id":26,"collection":"tbl_user_detail","field":"country","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":8,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user_detail","field":"country","sort":8,"group":null}	\N
111	129	directus_fields	28	{"id":28,"collection":"tbl_user_detail","field":"language","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":9,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user_detail","field":"language","sort":9,"group":null}	\N
112	130	directus_fields	31	{"id":31,"collection":"tbl_user_detail","field":"stripe_id","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":10,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_user_detail","field":"stripe_id","sort":10,"group":null}	\N
113	131	directus_fields	41	{"id":41,"collection":"tbl_collection","field":"id","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":true,"hidden":true,"sort":1,"width":"full","translations":null,"note":null,"conditions":null,"required":false,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_collection","field":"id","sort":1,"group":null}	\N
114	132	directus_fields	43	{"id":43,"collection":"tbl_collection","field":"user_id","special":["m2o"],"interface":"select-dropdown-m2o","options":{"template":"{{email}}"},"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":2,"width":"full","translations":null,"note":null,"conditions":null,"required":true,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_collection","field":"user_id","sort":2,"group":null}	\N
115	133	directus_fields	42	{"id":42,"collection":"tbl_collection","field":"name","special":null,"interface":"input","options":null,"display":null,"display_options":null,"readonly":false,"hidden":false,"sort":3,"width":"full","translations":null,"note":null,"conditions":null,"required":true,"group":null,"validation":null,"validation_message":null}	{"collection":"tbl_collection","field":"name","sort":3,"group":null}	\N
\.


--
-- Data for Name: directus_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directus_roles (id, name, icon, description, ip_access, enforce_tfa, admin_access, app_access) FROM stdin;
f2290c1f-4810-4ade-88e7-b6dbc3b3ff78	Administrator	verified	$t:admin_description	\N	f	t	t
\.


--
-- Data for Name: directus_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directus_sessions (token, "user", expires, ip, user_agent, share, origin) FROM stdin;
l7HPjVByZhp-X5aAmJu284jwUptU8ER3K5eaLWuPLPk9v0kG9qVlpfHcxWX4PfNC	d303fde0-cf5e-457d-9e14-7fcc4a4594dc	2023-10-18 11:20:45.204+00	172.18.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36	\N	http://localhost:5002
\.


--
-- Data for Name: directus_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directus_settings (id, project_name, project_url, project_color, project_logo, public_foreground, public_background, public_note, auth_login_attempts, auth_password_policy, storage_asset_transform, storage_asset_presets, custom_css, storage_default_folder, basemaps, mapbox_key, module_bar, project_descriptor, default_language, custom_aspect_ratios) FROM stdin;
\.


--
-- Data for Name: directus_shares; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directus_shares (id, name, collection, item, role, password, user_created, date_created, date_start, date_end, times_used, max_uses) FROM stdin;
\.


--
-- Data for Name: directus_translations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directus_translations (id, language, key, value) FROM stdin;
\.


--
-- Data for Name: directus_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directus_users (id, first_name, last_name, email, password, location, title, description, tags, avatar, language, theme, tfa_secret, status, role, token, last_access, last_page, provider, external_identifier, auth_data, email_notifications) FROM stdin;
d303fde0-cf5e-457d-9e14-7fcc4a4594dc	Admin	User	admin@example.com	$argon2id$v=19$m=65536,t=3,p=4$4t6zWALlkei0KhxKhMtETA$+f2HYDH/xPXYTLJc3yh2El+WdkFTt/sb7OcbWIR8ybM	\N	\N	\N	\N	\N	\N	auto	\N	active	f2290c1f-4810-4ade-88e7-b6dbc3b3ff78	\N	2023-10-11 11:20:45.208+00	/content/tbl_user	default	\N	\N	t
\.


--
-- Data for Name: directus_webhooks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directus_webhooks (id, name, method, url, status, data, actions, collections, headers) FROM stdin;
\.


--
-- Data for Name: tbl_collection; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tbl_collection (id, name, user_id) FROM stdin;
1	test	13
2	varchar	16
\.


--
-- Data for Name: tbl_site; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tbl_site (id, user_id, timeout, url, width, height, collection_id, useragent, cookies, frequency, freqtime, freqtimezone) FROM stdin;
1	16	30	http://www.example.com	1024	8000	\N	\N	\N	daily	\N	\N
2	16	30	http://www.example.com/about	1024	8000	\N	\N	\N	daily	\N	\N
3	16	30	http://www.example.com/contact	1024	8000	\N	\N	\N	daily	\N	\N
7	16	30	http://www.example.com/hello	\N	\N	\N	\N	\N	daily	\N	\N
15	16	30	http://www.example.com/faq1	\N	\N	\N	\N	\N	daily	\N	\N
16	16	30	http://www.example.com/faq2	\N	\N	\N	\N	\N	daily	\N	\N
19	16	30	http://www.example.com/faq3	\N	\N	\N	\N	\N	daily	\N	\N
\.


--
-- Data for Name: tbl_user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tbl_user (date_created, date_updated, email, firstname, id, lastname, pass, session, status, uid, verify_code) FROM stdin;
2023-08-07 06:04:17.630616+00	2023-08-07 06:04:17.630616+00	js+dev1@rokt.io	joe	12		1d8701c567e444f4b659357142028a0a~8a7d39b717bbfb0e85b139100f6010036dc0e5e2fc6a97b3d3a9b405e0fd687d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI2MzdmMzg2ZjQ3YTQ0YzYzOGM1YTA0ZWE3ZjIxMWE0YyIsInJuZCI6ImM5MDM0ZDJmODcxODQwZmY4NzRhMzVkMzlkODgxODdlIiwiaWF0IjoxNjkxNTQ5NzY1fQ==.WmpxMDAyK1QzY2wzcDZON3cwSnNNSEZMamw0V0ZlVGJaN0hvd1dNdExXRT0=	V	637f386f-47a4-4c63-8c5a-04ea7f211a4c	\N
2023-08-08 12:36:51.014108+00	2023-08-08 12:36:51.014108+00	js+dev5@rokt.io	joe	16		4a87880b5428415db7d8f429792569db~49e6cf4e2301254c92aea117de3ed05ecd4410b5a7892526da4158eb4692fa9e	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhYjdlMTMyY2U5ODk0NWNjYjYyZDQyNDZkZDgzNmJiMyIsInJuZCI6ImViNjBmNzdiMmM1NDRiODE4OTFmYTY0ZjAwYTVlOWM0IiwiaWF0IjoxNjkyNzA1MzU2fQ==.MXBTeW9zTkRranVIRlFKZkY0cjloNkFyME9IM0pRR1pVWG1MUTNNS21TUT0=	V	ab7e132c-e989-45cc-b62d-4246dd836bb3	\N
2023-09-21 07:21:12.844536+00	2023-09-21 07:21:12.844536+00	js+dev6@rokt.io	joe	17		c0eaecb20a97449196d7bea497e413c9~6923b1c28ac468d1088a5c4ed313bb9aca7abec71a6243b5e4f4e810e8a19d2e	\N	P	ddb175b3-ad7e-4f70-beac-5af594b6c968	af2bca98-a298-46cc-87e2-5ef88138cbe7
2023-09-21 08:08:06.831804+00	2023-09-21 08:08:06.831804+00	js+dev7@rokt.io	joe	18		63d0da19296146a9b0520979d108c209~ef62c75aa0421bedb135b162141200572109a59e94f14b3271237d586e230f39	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIwMWU2ZWE5ZjFkMWU0NDc3YWM0MmY3NjQwNjQ5N2Q4MyIsInJuZCI6IjFiMDIyOWFlODI4MjRmYThhNDQwNTU0ZThiM2IyYzU5IiwiaWF0IjoxNjk1MjgzNzI2fQ==.TVhQUm94OUlRN1AzcEd6UzlCaFBudmtlUis1dSs3TkwveDBuOHBvK2xpTT0=	V	01e6ea9f-1d1e-4477-ac42-f76406497d83	7c9a949a-c2c5-4c9e-8a4c-75b9d1f135e3
2023-08-07 07:41:31.608745+00	2023-08-07 07:41:31.608745+00	js+dev2@rokt.io	Jim	13	Smith	a43dfdecd5ce4d929d8db0234db16d87~f6b42154e2f7a54a45f639ecdf1b505f99248444a7406074de6b6df803363156	\N	P	d5ce6170-eb9d-47cf-9f68-9f8fb5723847	8b9323c6-6acb-4864-907d-dd6ead59d2d8
2023-08-08 12:34:08.872448+00	2023-08-08 12:34:08.872448+00	js+dev3@rokt.io	joe	14		5b237418fb694ec7a7cdc4170de51a4a~e1ba2d2bad9d9af478ef9c4ca655ef186b67b6e38606f6fdd3cec3cda942f687	\N	V	e198700f-ae1b-4c15-8979-3c4740fcae83	\N
2023-08-08 12:35:37.216241+00	2023-08-08 12:35:37.216241+00	js+dev4@rokt.io	joe	15		c57c047c9aad4c20ad9ee44e49ddb7ee~db9168c3f9649617651422973f8525b2c45470f185fd251b944f7c1d902c2fce	\N	V	7181f9cb-8dfc-4f14-9c9f-085e21d0eadd	\N
\.


--
-- Data for Name: tbl_user_detail; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tbl_user_detail (address, city, company_name, country, id, language, postcode, state, stripe_id, user_id) FROM stdin;
\N	\N	Rocket Lab	\N	10	\N	\N	\N	\N	12
\.


--
-- Name: directus_activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.directus_activity_id_seq', 139, true);


--
-- Name: directus_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.directus_fields_id_seq', 53, true);


--
-- Name: directus_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.directus_notifications_id_seq', 1, false);


--
-- Name: directus_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.directus_permissions_id_seq', 1, false);


--
-- Name: directus_presets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.directus_presets_id_seq', 8, true);


--
-- Name: directus_relations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.directus_relations_id_seq', 4, true);


--
-- Name: directus_revisions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.directus_revisions_id_seq', 116, true);


--
-- Name: directus_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.directus_settings_id_seq', 1, false);


--
-- Name: directus_webhooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.directus_webhooks_id_seq', 1, false);


--
-- Name: tbl_collection_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tbl_collection_id_seq', 2, true);


--
-- Name: tbl_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tbl_site_id_seq', 19, true);


--
-- Name: tbl_user_detail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tbl_user_detail_id_seq', 10, true);


--
-- Name: tbl_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tbl_user_id_seq', 18, true);


--
-- Name: directus_activity directus_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_activity
    ADD CONSTRAINT directus_activity_pkey PRIMARY KEY (id);


--
-- Name: directus_collections directus_collections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_collections
    ADD CONSTRAINT directus_collections_pkey PRIMARY KEY (collection);


--
-- Name: directus_dashboards directus_dashboards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_dashboards
    ADD CONSTRAINT directus_dashboards_pkey PRIMARY KEY (id);


--
-- Name: directus_fields directus_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_fields
    ADD CONSTRAINT directus_fields_pkey PRIMARY KEY (id);


--
-- Name: directus_files directus_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_files
    ADD CONSTRAINT directus_files_pkey PRIMARY KEY (id);


--
-- Name: directus_flows directus_flows_operation_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_flows
    ADD CONSTRAINT directus_flows_operation_unique UNIQUE (operation);


--
-- Name: directus_flows directus_flows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_flows
    ADD CONSTRAINT directus_flows_pkey PRIMARY KEY (id);


--
-- Name: directus_folders directus_folders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_folders
    ADD CONSTRAINT directus_folders_pkey PRIMARY KEY (id);


--
-- Name: directus_migrations directus_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_migrations
    ADD CONSTRAINT directus_migrations_pkey PRIMARY KEY (version);


--
-- Name: directus_notifications directus_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_notifications
    ADD CONSTRAINT directus_notifications_pkey PRIMARY KEY (id);


--
-- Name: directus_operations directus_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_operations
    ADD CONSTRAINT directus_operations_pkey PRIMARY KEY (id);


--
-- Name: directus_operations directus_operations_reject_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_operations
    ADD CONSTRAINT directus_operations_reject_unique UNIQUE (reject);


--
-- Name: directus_operations directus_operations_resolve_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_operations
    ADD CONSTRAINT directus_operations_resolve_unique UNIQUE (resolve);


--
-- Name: directus_panels directus_panels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_panels
    ADD CONSTRAINT directus_panels_pkey PRIMARY KEY (id);


--
-- Name: directus_permissions directus_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_permissions
    ADD CONSTRAINT directus_permissions_pkey PRIMARY KEY (id);


--
-- Name: directus_presets directus_presets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_presets
    ADD CONSTRAINT directus_presets_pkey PRIMARY KEY (id);


--
-- Name: directus_relations directus_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_relations
    ADD CONSTRAINT directus_relations_pkey PRIMARY KEY (id);


--
-- Name: directus_revisions directus_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_revisions
    ADD CONSTRAINT directus_revisions_pkey PRIMARY KEY (id);


--
-- Name: directus_roles directus_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_roles
    ADD CONSTRAINT directus_roles_pkey PRIMARY KEY (id);


--
-- Name: directus_sessions directus_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_sessions
    ADD CONSTRAINT directus_sessions_pkey PRIMARY KEY (token);


--
-- Name: directus_settings directus_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_settings
    ADD CONSTRAINT directus_settings_pkey PRIMARY KEY (id);


--
-- Name: directus_shares directus_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_shares
    ADD CONSTRAINT directus_shares_pkey PRIMARY KEY (id);


--
-- Name: directus_translations directus_translations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_translations
    ADD CONSTRAINT directus_translations_pkey PRIMARY KEY (id);


--
-- Name: directus_users directus_users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_users
    ADD CONSTRAINT directus_users_email_unique UNIQUE (email);


--
-- Name: directus_users directus_users_external_identifier_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_users
    ADD CONSTRAINT directus_users_external_identifier_unique UNIQUE (external_identifier);


--
-- Name: directus_users directus_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_users
    ADD CONSTRAINT directus_users_pkey PRIMARY KEY (id);


--
-- Name: directus_users directus_users_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_users
    ADD CONSTRAINT directus_users_token_unique UNIQUE (token);


--
-- Name: directus_webhooks directus_webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_webhooks
    ADD CONSTRAINT directus_webhooks_pkey PRIMARY KEY (id);


--
-- Name: tbl_collection tbl_collection_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tbl_collection
    ADD CONSTRAINT tbl_collection_pkey PRIMARY KEY (id);


--
-- Name: tbl_site tbl_site_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tbl_site
    ADD CONSTRAINT tbl_site_pkey PRIMARY KEY (id);


--
-- Name: tbl_user_detail tbl_user_detail_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tbl_user_detail
    ADD CONSTRAINT tbl_user_detail_pkey PRIMARY KEY (id);


--
-- Name: tbl_user_detail tbl_user_detail_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tbl_user_detail
    ADD CONSTRAINT tbl_user_detail_user_id_unique UNIQUE (user_id);


--
-- Name: tbl_user tbl_user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tbl_user
    ADD CONSTRAINT tbl_user_pkey PRIMARY KEY (id);


--
-- Name: tbl_user tbl_user_uid_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tbl_user
    ADD CONSTRAINT tbl_user_uid_unique UNIQUE (uid);


--
-- Name: tbl_user_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tbl_user_email_idx ON public.tbl_user USING btree (email);


--
-- Name: tbl_user_session_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tbl_user_session_idx ON public.tbl_user USING btree (session);


--
-- Name: tbl_user_uid_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tbl_user_uid_idx ON public.tbl_user USING btree (uid);


--
-- Name: tbl_user_verify_code_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tbl_user_verify_code_idx ON public.tbl_user USING btree (verify_code);


--
-- Name: directus_collections directus_collections_group_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_collections
    ADD CONSTRAINT directus_collections_group_foreign FOREIGN KEY ("group") REFERENCES public.directus_collections(collection);


--
-- Name: directus_dashboards directus_dashboards_user_created_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_dashboards
    ADD CONSTRAINT directus_dashboards_user_created_foreign FOREIGN KEY (user_created) REFERENCES public.directus_users(id) ON DELETE SET NULL;


--
-- Name: directus_files directus_files_folder_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_files
    ADD CONSTRAINT directus_files_folder_foreign FOREIGN KEY (folder) REFERENCES public.directus_folders(id) ON DELETE SET NULL;


--
-- Name: directus_files directus_files_modified_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_files
    ADD CONSTRAINT directus_files_modified_by_foreign FOREIGN KEY (modified_by) REFERENCES public.directus_users(id);


--
-- Name: directus_files directus_files_uploaded_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_files
    ADD CONSTRAINT directus_files_uploaded_by_foreign FOREIGN KEY (uploaded_by) REFERENCES public.directus_users(id);


--
-- Name: directus_flows directus_flows_user_created_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_flows
    ADD CONSTRAINT directus_flows_user_created_foreign FOREIGN KEY (user_created) REFERENCES public.directus_users(id) ON DELETE SET NULL;


--
-- Name: directus_folders directus_folders_parent_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_folders
    ADD CONSTRAINT directus_folders_parent_foreign FOREIGN KEY (parent) REFERENCES public.directus_folders(id);


--
-- Name: directus_notifications directus_notifications_recipient_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_notifications
    ADD CONSTRAINT directus_notifications_recipient_foreign FOREIGN KEY (recipient) REFERENCES public.directus_users(id) ON DELETE CASCADE;


--
-- Name: directus_notifications directus_notifications_sender_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_notifications
    ADD CONSTRAINT directus_notifications_sender_foreign FOREIGN KEY (sender) REFERENCES public.directus_users(id);


--
-- Name: directus_operations directus_operations_flow_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_operations
    ADD CONSTRAINT directus_operations_flow_foreign FOREIGN KEY (flow) REFERENCES public.directus_flows(id) ON DELETE CASCADE;


--
-- Name: directus_operations directus_operations_reject_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_operations
    ADD CONSTRAINT directus_operations_reject_foreign FOREIGN KEY (reject) REFERENCES public.directus_operations(id);


--
-- Name: directus_operations directus_operations_resolve_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_operations
    ADD CONSTRAINT directus_operations_resolve_foreign FOREIGN KEY (resolve) REFERENCES public.directus_operations(id);


--
-- Name: directus_operations directus_operations_user_created_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_operations
    ADD CONSTRAINT directus_operations_user_created_foreign FOREIGN KEY (user_created) REFERENCES public.directus_users(id) ON DELETE SET NULL;


--
-- Name: directus_panels directus_panels_dashboard_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_panels
    ADD CONSTRAINT directus_panels_dashboard_foreign FOREIGN KEY (dashboard) REFERENCES public.directus_dashboards(id) ON DELETE CASCADE;


--
-- Name: directus_panels directus_panels_user_created_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_panels
    ADD CONSTRAINT directus_panels_user_created_foreign FOREIGN KEY (user_created) REFERENCES public.directus_users(id) ON DELETE SET NULL;


--
-- Name: directus_permissions directus_permissions_role_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_permissions
    ADD CONSTRAINT directus_permissions_role_foreign FOREIGN KEY (role) REFERENCES public.directus_roles(id) ON DELETE CASCADE;


--
-- Name: directus_presets directus_presets_role_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_presets
    ADD CONSTRAINT directus_presets_role_foreign FOREIGN KEY (role) REFERENCES public.directus_roles(id) ON DELETE CASCADE;


--
-- Name: directus_presets directus_presets_user_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_presets
    ADD CONSTRAINT directus_presets_user_foreign FOREIGN KEY ("user") REFERENCES public.directus_users(id) ON DELETE CASCADE;


--
-- Name: directus_revisions directus_revisions_activity_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_revisions
    ADD CONSTRAINT directus_revisions_activity_foreign FOREIGN KEY (activity) REFERENCES public.directus_activity(id) ON DELETE CASCADE;


--
-- Name: directus_revisions directus_revisions_parent_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_revisions
    ADD CONSTRAINT directus_revisions_parent_foreign FOREIGN KEY (parent) REFERENCES public.directus_revisions(id);


--
-- Name: directus_sessions directus_sessions_share_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_sessions
    ADD CONSTRAINT directus_sessions_share_foreign FOREIGN KEY (share) REFERENCES public.directus_shares(id) ON DELETE CASCADE;


--
-- Name: directus_sessions directus_sessions_user_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_sessions
    ADD CONSTRAINT directus_sessions_user_foreign FOREIGN KEY ("user") REFERENCES public.directus_users(id) ON DELETE CASCADE;


--
-- Name: directus_settings directus_settings_project_logo_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_settings
    ADD CONSTRAINT directus_settings_project_logo_foreign FOREIGN KEY (project_logo) REFERENCES public.directus_files(id);


--
-- Name: directus_settings directus_settings_public_background_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_settings
    ADD CONSTRAINT directus_settings_public_background_foreign FOREIGN KEY (public_background) REFERENCES public.directus_files(id);


--
-- Name: directus_settings directus_settings_public_foreground_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_settings
    ADD CONSTRAINT directus_settings_public_foreground_foreign FOREIGN KEY (public_foreground) REFERENCES public.directus_files(id);


--
-- Name: directus_settings directus_settings_storage_default_folder_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_settings
    ADD CONSTRAINT directus_settings_storage_default_folder_foreign FOREIGN KEY (storage_default_folder) REFERENCES public.directus_folders(id) ON DELETE SET NULL;


--
-- Name: directus_shares directus_shares_collection_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_shares
    ADD CONSTRAINT directus_shares_collection_foreign FOREIGN KEY (collection) REFERENCES public.directus_collections(collection) ON DELETE CASCADE;


--
-- Name: directus_shares directus_shares_role_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_shares
    ADD CONSTRAINT directus_shares_role_foreign FOREIGN KEY (role) REFERENCES public.directus_roles(id) ON DELETE CASCADE;


--
-- Name: directus_shares directus_shares_user_created_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_shares
    ADD CONSTRAINT directus_shares_user_created_foreign FOREIGN KEY (user_created) REFERENCES public.directus_users(id) ON DELETE SET NULL;


--
-- Name: directus_users directus_users_role_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directus_users
    ADD CONSTRAINT directus_users_role_foreign FOREIGN KEY (role) REFERENCES public.directus_roles(id) ON DELETE SET NULL;


--
-- Name: tbl_collection tbl_collection_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tbl_collection
    ADD CONSTRAINT tbl_collection_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.tbl_user(id);


--
-- Name: tbl_site tbl_site_collection_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tbl_site
    ADD CONSTRAINT tbl_site_collection_id_foreign FOREIGN KEY (collection_id) REFERENCES public.tbl_collection(id) ON DELETE CASCADE;


--
-- Name: tbl_site tbl_site_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tbl_site
    ADD CONSTRAINT tbl_site_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.tbl_user(id);


--
-- Name: tbl_user_detail tbl_user_detail_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tbl_user_detail
    ADD CONSTRAINT tbl_user_detail_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.tbl_user(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA public TO rlwm_user;


--
-- PostgreSQL database dump complete
--

